﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Forms;

using AdventOfCode2018.Core;

namespace $safeprojectname$
{
    class DayX
    {
        static System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();



        #region Support Methods

        #endregion
    }
}